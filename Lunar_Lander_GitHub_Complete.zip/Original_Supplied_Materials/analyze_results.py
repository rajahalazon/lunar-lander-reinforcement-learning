"""Recompute tables and figures from the original exported evaluation dataset.
Usage: pip install pandas numpy matplotlib; python analyze_results.py
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

base = Path(__file__).resolve().parent
figs = base / "figures"
figs.mkdir(exist_ok=True)
df = pd.read_csv(base / "final_results.csv")
expected = {"Original PPO", "Time Penalty", "Hover Reward", "Corrected Reward"}
assert len(df) == 400 and set(df["model"]) == expected
assert not df.isna().any().any()
df["slow_fraction"] = df["slow_upright_airborne_frames"] / df["duration_frames"]
summary = df.groupby("model", sort=False).agg(
    episodes=("seed", "size"),
    mean_score=("score", "mean"),
    score_sd=("score", "std"),
    successes=("successful_landing", "sum"),
    mean_duration_frames=("duration_frames", "mean"),
    mean_slow_upright_frames=("slow_upright_airborne_frames", "mean"),
    mean_slow_fraction=("slow_fraction", "mean"),
)
summary["success_rate_pct"] = summary["successes"] / summary["episodes"] * 100
summary.to_csv(base / "summary_statistics_recomputed.csv")
print(summary.round(2).to_string())

order = ["Original PPO", "Time Penalty", "Hover Reward", "Corrected Reward"]
labels = ["Original PPO", "Time penalty", "Hover reward", "Corrected reward"]
for col, ylabel, filename in [
    ("success_rate_pct", "Landing success (%)", "landing_success_recomputed.png"),
    ("mean_score", "Mean episode score", "mean_score_recomputed.png"),
    ("mean_slow_fraction", "Mean slow/upright fraction", "slow_fraction_recomputed.png"),
]:
    fig, ax = plt.subplots(figsize=(9, 4.5))
    vals = summary.loc[order, col].values
    ax.bar(range(4), vals)
    ax.set_xticks(range(4), labels)
    ax.set_ylabel(ylabel)
    ax.set_title(ylabel + " | 100 episodes per agent")
    ax.grid(axis="y", alpha=.2)
    fig.tight_layout()
    fig.savefig(figs / filename, dpi=175)
    plt.close(fig)
