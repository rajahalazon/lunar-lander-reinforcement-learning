# Autonomous Lunar Landing with Reinforcement Learning

**Independent Engineering Project | October 2026**

Four policies were trained for the Gymnasium `LunarLander-v3` benchmark using Stable-Baselines3 PPO. We designed three reward variations to explore episode efficiency, reward hacking, and corrective reward shaping.

## Verified evaluation results

All four trained checkpoints were tested with **100 matching seeds (1000–1099)**, deterministic policies, and the **unmodified** Gymnasium reward.

| Policy | Mean score | Safe touchdowns | Mean duration (frames) | Slow/upright airborne frames |
|---|---:|---:|---:|---:|
| Original PPO | 177.53 | 75/100 | 301.91 | 28.14 |
| Time penalty (-0.01/step) | -14.98 | 27/100 | 382.45 | 148.82 |
| Hover-friendly bonus (+1 while slow/upright) | -60.63 | 0/100 | 931.89 | 842.38 |
| Change-based correction (+2 Δstability - 0.01/step) | 90.21 | 55/100 | 503.84 | 261.74 |

![Landing success chart](figures/01_landing_success.png)

## The engineering problem

A flawed reward encouraged the lander to stay slow and upright in midair rather than finish the landing. It spent an average of 842 slow/upright airborne frames per attempt, achieved 0 successful touchdowns, and hit the 1,000-frame limit in 87/100 tests. Modifying the reward to pay for *improving* stability instead of repeatedly paying to *maintain* stability recovered 55/100 safe landings. The original PPO still performed best at 75/100.

This is **an observed result for these four trained checkpoints**, not proof about the general superiority of reward functions across independent training runs.

## Experiment design

- **Environment:** Gymnasium `LunarLander-v3`, 8D observation, 4 discrete actions.
- **Algorithm:** Stable-Baselines3 PPO with `MlpPolicy`, CPU, requested 500,000 training timesteps per policy.
- **Agents:** baseline; -0.01 reward per frame; +1 for slow/upright nonterminal frames; 2 times change in negative absolute horizontal speed + vertical speed + attitude plus -0.01 per frame.
- **Evaluation:** 100 episodes per agent; same seeds; original game reward; deterministic actions.
- **Success flag:** evaluation script used termination and terminal base reward >= +100. Direct touchdown-state classification was not independently recorded.
- **Slow/upright metric:** horizontal and vertical velocity magnitudes under 0.2, absolute angle under 0.15, both legs off ground, nonterminal. This **does not prove fixed-altitude hovering**.

## Contents

- `Lunar_Lander_Engineering_Project_Report.pdf` - illustrated engineering report with methodology, results, confidence intervals, caveats and references.
- `final_results.csv` - all 400 original user-exported episodes.
- `summary_statistics.csv` and `paired_comparisons.csv` - derived analysis tables.
- `figures/` - measured performance figures.
- `analyze_results.py` - standalone script that reproduces core summaries and graphs from the CSV.

## Run the analysis

Requires Python 3.10+ with pandas, numpy, and matplotlib:

```bash
python -m pip install pandas numpy matplotlib
python analyze_results.py
```

## Training source and model availability

**Important:** This evidence package contains the shared evaluation CSV and report. The user-run `train.py`, `train_shaped.py`, `train_hover.py`, `train_fixed.py`, reward wrappers and `lunar_lander_*.zip` model files were **not uploaded** with that CSV, so they are **not included** in this ZIP. Before public release, copy the genuine local source and checkpoints into the repository (omit your `.venv` folder and large binaries if a hosting-size limit applies). Do not present the analysis helper as a substitute for the original training code.

**Follow-up work:** evaluate >=5 independent training seeds per condition, log altitude/engine control to confirm hover, and generate actual recorded gameplay videos and time-series training curves.

## Background sources

1. [Gymnasium Lunar Lander](https://gymnasium.farama.org/environments/box2d/lunar_lander/)
2. [Gymnasium: Implementing Custom Wrappers](https://gymnasium.farama.org/main/tutorials/gymnasium_basics/implementing_custom_wrappers/)
3. [Stable-Baselines3 PPO documentation](https://stable-baselines3.readthedocs.io/en/master/modules/ppo.html)
4. [PPO paper (Schulman et al., 2017)](https://arxiv.org/abs/1707.06347)
