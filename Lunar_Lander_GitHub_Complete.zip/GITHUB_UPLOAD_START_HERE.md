# GitHub upload guide

This package contains the entire supplied Claude portfolio plus **reconstructed training/evaluation code** from the commands shared in the ChatGPT conversation.

## Critical provenance note
The scripts in `Original_Training_Code_Reconstructed/` are **reconstructions**, not independently verified byte-for-byte copies of the files that ran on the user's Windows computer. They were not supplied in Claude’s ZIP. Replace them with the actual scripts from `C:\Users\halaz\lunar-lander-ai` before claiming exact reproduction. The original saved PPO model files are also absent.

## Publishing
Extract this archive, create a public GitHub repository, and upload the **contents** of this directory. GitHub does not automatically unpack uploaded ZIP archives.

The primary project README is `README.md`. The supplied engineering report is `Final Engineering Report.pdf`. The CSV is under `Original_Supplied_Materials/final_results.csv`.

## Running reconstructed code
Install dependencies from `Original_Training_Code_Reconstructed/requirements.txt`; run the training scripts from within that directory. Evaluation requires the four trained model ZIP files in the same working directory.
